
# Javascript
 - modulo 15.
 ## validação do formulario cadastro.
 - mensagem de erro de nao preenchimento.
 - mensagem de erro de envio vazio.
 - mensagem de sucesso.
 ## validação do calculo de media.
 - mensagem de erro de não preenchimento
 - mensagem do calculo da media das notas
